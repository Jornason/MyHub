#include"mesh.h"
#include<fstream>
#include<iostream>
#include<vector>
#include<string>
#include<sstream>
#include<queue>
#include<algorithm>
#include<thread>
using namespace std;

Mesh::Mesh(string name,string filename,int orientation):Object(name)
{
  //This is the constructor for a mesh. It also finds if the mesh can support
  //itself without the need for scaffolding while 3D printing

  //The first step is to read in the mesh file (*.obj.txt) and store the vertex
  //coordinates and which vertices correspond to triangle face

  //The second step is to divide the model into at least as many crossections
  //so that all of the vertices in the model are contained in exactly one of the
  //cross sections

  //The third step is to take the slices that have been created and compare
  //every point on the perimeter of that slice with the slice that is directly
  //below it. How well the lower slice contains this point (is it hanging out
  //over the edge or not) determine's is stability. Negative numbers indicate
  //good support and therefore good stability. Positive numbers indicate
  //overhanging bits that might drop off depending on the material being used
  //to print

  //The fourth step is to print all the slice data along with the stability of
  //each point on each slice for debugging purposes

  if(readInputMesh(filename,orientation))
  {
    cout<<"mesh read orientation= "<<orientation<<endl;
  }
  else
  {
    cout<<"mesh file read failed"<<endl;
  }
  createGraph();
  cutTheModelIntoSlices();
  cout<<"cut into slice"<<endl;
  computeStabilityModel();
  cout<<"computed stability"<<endl;
  adjustStability();
  cout<<"adjusted stability"<<endl;
  printSlices();
}

bool Mesh::readInputMesh(string&filenm, int orientation)
{
  //The purpose of this method is to read an input file that describes an object
  //as a series of points in 3D space as well as how those points connect to
  //form triangular faces

  //The file is opened and each line is read in. The first token in the line
  //tells the program what is described in the line (either vertex coordinates
  //or a triangle face)

  //v means that it is a vertex and 3 double values are read in describing the
  //x, y, and z coordinates of the vertex. These coordinates are stored in a
  //vector

  //f means that it is a triangle face. Three integer values will describe the
  //indices of the vertices in the vertex vector that make up this triangle face
  string line;
  vertexData.clear();
  triangleIndices.clear();
  const char*file=filenm.c_str();
  ifstream ifile(file);
  if(!ifile.is_open())
  {
    cout<<"failed to open"<<endl;
    return false;
  }
  while(getline(ifile,line))
  {
    stringstream linestr;
    linestr<<line;
    string code;
    linestr>>code;
    if(code=="f")
    {
      int a;
      if(line.find("//")!=string::npos)
      {
        linestr>>a;
        linestr.ignore(100,' ');
        a--;
        triangleIndices.push_back(a);
        linestr>>a;
        linestr.ignore(100,' ');
        a--;
        triangleIndices.push_back(a);
        linestr>>a;
        a--;
        triangleIndices.push_back(a);
      }
      else
      {
        linestr>>a;
        a--;
        triangleIndices.push_back(a);
        linestr>>a;
        a--;
        triangleIndices.push_back(a);
        linestr>>a;
        a--;
        triangleIndices.push_back(a);
      }
    }
    else if(code=="v")
    {
      VertexAttribs v;
      linestr>>v.x;
      linestr>>v.y;
      linestr>>v.z;
      v.w=1;
      double temp;
      switch(orientation)
      {
        case 1:
          v.y*=-1.0;
          break;
        case 2:
          temp = v.y;
          v.y=v.z;
          v.z=temp;
          break;
        case 3:
          temp = v.y;
          v.y=v.z;
          v.z=temp;
          v.y*=-1.0;
          break;
        case 4:
          temp = v.y;
          v.y=v.x;
          v.x=temp;
          break;
        case 5:
          temp = v.y;
          v.y=v.x;
          v.x=temp;
          v.y*=-1.0;
          break;
      }

      vertexData.push_back(v);
    }
    else
    {
      continue;
    }
  }
  ifile.close();
  return true;
}

void Mesh::createGraph()
{
  //The purpose of this method is organize and relate each vertex to the
  //vertices that it connects directly to (this forming edges, which form
  //triangles, which form faces, which form the model).

  //This is done by using a map of maps data structure. The outer map's keys
  //are integer values corresponding to an index in the vertex data vector
  //the mapped value is a map that contains all of the connected vertices. The

  //This innermap contains as many values as there are edges that connect to the
  //outermap's key value. The innermap's key is the index in the vector of
  //vertex data that contains the connected vertex (which forms an edge). The
  //mapped value in the inner map connects to a set of integer values. Each
  //integer in this set represents an index in the triangleIndices vector. This
  //index marks the first of 3 indices that will correspond to the vertices in
  //the vertex data vector. The combination of these 3 vertices is, of course,
  //a triangle. Therefore, each integer in the set can be thought of as
  //representing a triangle in this model. These are the triangles that contain
  //the edge described in this innerMap entry. There should be exactly 2 values
  //in this set in a model that described a real-world 3D object, since in such
  //a model, only two triangle faces match up to one edge.

  for(unsigned int i=0;i<triangleIndices.size();i+=3)
  {
    InnerMap innerMaps[3];
    TriSet emptySet;
    innerMaps[0].insert(make_pair(triangleIndices[i+1],emptySet));
    innerMaps[0].insert(make_pair(triangleIndices[i+2],emptySet));
    graph.insert(make_pair(triangleIndices[i],innerMaps[0]));
    graph[triangleIndices[i]][triangleIndices[i+1]].insert(i);
    graph[triangleIndices[i]][triangleIndices[i+2]].insert(i);
    innerMaps[1].insert(make_pair(triangleIndices[i],emptySet));
    innerMaps[1].insert(make_pair(triangleIndices[i+2],emptySet));
    graph.insert(make_pair(triangleIndices[i+1],innerMaps[1]));
    graph[triangleIndices[i+1]][triangleIndices[i]].insert(i);
    graph[triangleIndices[i+1]][triangleIndices[i+2]].insert(i);
    innerMaps[2].insert(make_pair(triangleIndices[i],emptySet));
    innerMaps[2].insert(make_pair(triangleIndices[i+1],emptySet));
    graph.insert(make_pair(triangleIndices[i+2],innerMaps[2]));
    graph[triangleIndices[i+2]][triangleIndices[i]].insert(i);
    graph[triangleIndices[i+2]][triangleIndices[i+1]].insert(i);
  }
}

bool sortY(const VertexAttribs&lhs,const VertexAttribs&rhs)
{
  //This is a predicate used to compare to vertices by their y value

  return lhs.y<rhs.y;
}

void Mesh::cutTheModelIntoSlices()
{
  //The purpose of this method is to take a graph and use it to define a series
  //of cross sections in the model. Each of the vertices in the model will be
  //contained in exactly one of the cross sections. A maximum distance between
  //cross sections is also defined

  //The first step is to find the smallest y value to start at as well as a good
  //maxmimum slice thickness
  double maximumYValue=vertexData[0].y;
  double minumumYValue=vertexData[0].y;
  unsigned int i;
  for(i=1;i<vertexData.size();i++)
  {
    if(vertexData[i].y>maximumYValue)
    {
      maximumYValue=vertexData[i].y;
    }
    if(vertexData[i].y<minumumYValue)
    {
      minumumYValue=vertexData[i].y;
    }
  }
  double heightOfModel=maximumYValue-minumumYValue;

  maximumThicknessOfSlice=heightOfModel/100.0;
  sortedVertexData=vertexData;
  sort(sortedVertexData.begin(),sortedVertexData.end(),sortY);
  y=sortedVertexData[0].y;
  i=0;
  //The next step is to start at the lowest vertex and create a slice that
  //contains it. Continue increasing the y value so that each vertex is
  //contained in exactly 1 slice. Also, if necessary add additional slices to
  //ensure that the slice thickness is not too great.

  //Before to reset the graph properly after creating a slice
  Graph savedGraph=graph;
  while(i<sortedVertexData.size()-1)
  {
    cout<<++i<<" out of "<<sortedVertexData.size()<<endl;
    createIndividualSlice();

    //Consume the graph as the y value increases so that vertices that no longer
    //matter for slice creation are removed from consideration
    cleanGraph(savedGraph);
    graph=savedGraph;

    //...and increment the y value appropriately
    if(i==sortedVertexData.size()-1)
    {
      y=sortedVertexData[i].y;
    }
    else if(y+maximumThicknessOfSlice<=sortedVertexData[i+1].y)
    {
      y+=maximumThicknessOfSlice;
    }
    else
    {
      y=sortedVertexData[i+1].y;
    }
  }
}

void Mesh::createIndividualSlice()
{
  //This method starts creating a single slice. It starts at the beginning of
  //the graph which represents the model and iteratos through looking for an
  //edge that straddles the y plane that represents the current cross section we
  //are trying to create

  GIter mainGraphIterator=graph.begin();
  for(;mainGraphIterator!=graph.end();mainGraphIterator++)
  {
    findStraddlingVertex(mainGraphIterator);
  }

}

void Mesh::findStraddlingVertex(GIter&mainGraphIterator)
{
  //This method can be thought of as testing all of the edges that connect
  //to a vertex and seeing if any of them staddle the y plane representing the
  //current cross section we are trying to create. If an edge that straddles is
  //found, we add that edge the the cross section. We then travel to the vertex
  //that this edge leads to. We then try the same process again until we have
  //completely traveled around the model at this y plane

  EList slice;
  int firstEdgeVertexIndex=(*mainGraphIterator).first;
  IMIter innerMapIterator=(*mainGraphIterator).second.begin();
  while(innerMapIterator!=(*mainGraphIterator).second.end())
  {
    int secondEdgeVertexIndex=(*innerMapIterator).first;
    double v1Y=vertexData[firstEdgeVertexIndex].y;
    double v2Y=vertexData[secondEdgeVertexIndex].y;
    if((v1Y>=y&&v2Y<y)||(v1Y<y&&v2Y>=y))
    {
      //Call the recursive helper function to travel to the next edge in the
      //cross section
      clipAlongYPlane(slice,firstEdgeVertexIndex,secondEdgeVertexIndex);
      //Then that method exits, you have a fully formed cross section. If it was
      //not empty, add it to the list of slice. Also, calculate all of the exact
      //3D points along the slice's perimeter by finding the exact spot that
      //each edge clipped the current y plane
      if(!slice.empty())
      {
        slicesData.push_back(getSliceVertices(slice));
        sliceVertexVec.push_back(slice);
      }
      break;
    }
    innerMapIterator++;
  }
}

void Mesh::clipAlongYPlane(EList&slice,int edgeVertex1,int edgeVertex2)
{
  //This method can be thought of as a recursive helper method for
  //findStraddlingVertex.

  //The method first checks to see if we have visited the triangle that contains
  //this edge before. If so, we are finished creating the slice because we have
  //navigated all the way around the perimeter of the model at this y plane

  //If we haven't been to this triangle before, we save the current edge and
  //then find the other triangle that contains this edge (only two triangles can
  //share an edge in a real-world 3D model)

  //One we have this other triangle, we find the next the next edge to add to
  //the slice. This function calls itself using that next edge

  TriSet triangleThatContainEdge=graph[edgeVertex1][edgeVertex2];
  if(triangleThatContainEdge.size()==0)
  {
    return;
  }
  slice.push_back(make_pair(edgeVertex1,edgeVertex2));
  int t=*triangleThatContainEdge.begin();
  int nextEdgeVertex1,nextEdgeVertex2;
  getNextSliceEdge(edgeVertex1,edgeVertex2,nextEdgeVertex1,nextEdgeVertex2,t);
  clipAlongYPlane(slice,nextEdgeVertex1,nextEdgeVertex2);
  return;
}

void Mesh::getNextSliceEdge(int eV1,int eV2,int&nxtEV1,int&nxtEV2,int t)
{
  //The purposes of this function is (a) to mark a triangle in the model as
  //already visisted to prevent the program from visiting it again and (b) to
  //find the edge that is in this triangle but is not in the slice already that
  //straddles the current y plane. All three edges in the triangle are tested.
  //Only one will be accepted.

  graph[triangleIndices[t]][triangleIndices[t+1]].erase(t);
  graph[triangleIndices[t]][triangleIndices[t+2]].erase(t);
  graph[triangleIndices[t+1]][triangleIndices[t]].erase(t);
  graph[triangleIndices[t+1]][triangleIndices[t+2]].erase(t);
  graph[triangleIndices[t+2]][triangleIndices[t]].erase(t);
  graph[triangleIndices[t+2]][triangleIndices[t+1]].erase(t);
  if(triangleIndices[t]!=eV1&&triangleIndices[t]!=eV2)
  {
    nxtEV2=triangleIndices[t];
    double nxtEV2y=vertexData[nxtEV2].y;
    double eV1y=vertexData[eV1].y;
    if((nxtEV2y>=y&&eV1y<y)||(nxtEV2y<y&&eV1y>=y))
    {
      nxtEV1=eV1;
    }
    else
    {
      nxtEV1=eV2;
    }
    return;
  }
  if(triangleIndices[t+1]!=eV1&&triangleIndices[t+1]!=eV2)
  {
    nxtEV2=triangleIndices[t+1];
    double nxtEV2y=vertexData[nxtEV2].y;
    double eV1y=vertexData[eV1].y;
    if((nxtEV2y>=y&&eV1y<y)||(nxtEV2y<y&&eV1y>=y))
    {
      nxtEV1=eV1;
    }
    else
    {
      nxtEV1=eV2;
    }
    return;
  }
  if(triangleIndices[t+2]!=eV1&&triangleIndices[t+2]!=eV2)
  {
    nxtEV2=triangleIndices[t+2];
    double nxtEV2y=vertexData[nxtEV2].y;
    double eV1y=vertexData[eV1].y;
    if((nxtEV2y>=y&&eV1y<y)||(nxtEV2y<y&&eV1y>=y))
    {
      nxtEV1=eV1;
    }
    else
    {
      nxtEV1=eV2;
    }
    return;
  }
}

vector<VertexAttribs> Mesh::getSliceVertices(EList&slice)
{
  //After the slice edges have been descibed as a series of vertex indices in
  //vertex data, it is necessary to find these vertex values and find where the
  //edge described actually clips the yPlane in 3D space. This exact point is
  //stored

  vector<VertexAttribs>sliceData;
  EIter sliceIter=slice.begin();
  while(sliceIter!=slice.end())
  {
    VertexAttribs v1=vertexData[(*sliceIter).first];
    VertexAttribs v2=vertexData[(*sliceIter).second];

    //Find the difference between the two vertices
    double xDif=v1.x-v2.x;
    double yDif=v1.y-v2.y;
    double zDif=v1.z-v2.z;

    //Find the difference between the first vertex's y value and the clipping y
    //plane
    double yDif2=v1.y-y;

    //Calculate the ratio between the two diffences in y values
    double ratio=yDif2/yDif;

    //Create and set a vertex that lies at exactly the point along the edge that
    //clips the y plane. Store it
    VertexAttribs v3;
    v3.x=v1.x-(xDif*ratio);
    v3.y=y;
    v3.z=v1.z-(zDif*ratio);
    v3.w=1;
    sliceData.push_back(v3);
    sliceIter++;
  }
  return sliceData;
}

void Mesh::cleanGraph(Graph&savedGraph)
{
  //This method was created to speed the process of slice creation by removing
  //vertices that need no longer be considered in the process of the creation of
  //slices.

  //An edge that can be ignored is an edge that has two end points that are BOTH
  //below the current y clipping plane

  GIter mainGraphIterator=savedGraph.begin();
  while(mainGraphIterator!=savedGraph.end())
  {
    double firstVertexYVal=vertexData[(*mainGraphIterator).first].y;
    IMIter innerMapIterator=(*mainGraphIterator).second.begin();
    while(innerMapIterator!=(*mainGraphIterator).second.end())
    {
      double secondVertexYVal=vertexData[(*innerMapIterator).first].y;
      if(firstVertexYVal<y&&secondVertexYVal<y)
      {
        (*mainGraphIterator).second.erase(innerMapIterator);
        innerMapIterator=(*mainGraphIterator).second.begin();
      }
      else
      {
        innerMapIterator++;
      }
    }

    //If all of the edges have been removed from this vertex, remove this vertex
    if((*mainGraphIterator).second.empty())
    {
      savedGraph.erase(mainGraphIterator);
      mainGraphIterator=savedGraph.begin();
    }
    else
    {
      mainGraphIterator++;
    }
  }
}

void Mesh::computeStabilityModel()
{
  //The purpose of this method is to calculate how well supported each vertex
  //in the model is by the ones below it

  //It uses multi-threading to speed the process

  //The program goes through each point that makes up each cross section and
  //checks to see how much it hangs over the edge of the slice below it. If it
  //hangs over, it is assigned a positive value. Otherwise, it is assigned a
  //negative value

  unsigned int i;
  vector<PointStability>firstSlice;
  //vector<PointStability>secondSlice;
  //vector<PointStability>thirdSlice;
  PointStability p;
  p.val=0.0;
  p.sliceIndex=0;
  p.supportIndex1=-1;
  p.supportIndex2=-1;
  for(i=0;i<slicesData[0].size();i++)
  {
    firstSlice.push_back(p);
  }
  //for(i=0;i<slicesData[1].size();i++)
  //{
  //  secondSlice.push_back(p);
  //}
  //for(i=0;i<slicesData[2].size();i++)
  //{
  //  thirdSlice.push_back(p);
  //}
  stabilityVector.push_back(firstSlice);
  //stabilityVector.push_back(secondSlice);
  //stabilityVector.push_back(thirdSlice);
  for(i=1;i<slicesData.size();i++)
  {
    vector<PointStability>stabilitySlice;
    for(unsigned int j=0;j<slicesData[i].size();j++)
    {
      PointStability q;
      q.val=0.0;
      q.sliceIndex=-1;
      q.supportIndex1=-1;
      q.supportIndex2=-1;
      stabilitySlice.push_back(q);
    }
    stabilityVector.push_back(stabilitySlice);
  }

  //Run as many threads as the hardware supports running at one time
  static unsigned int maxThreads=thread::hardware_concurrency();
  if(maxThreads<1)
  {
    maxThreads=1;
  }
  vector<thread> t;
  for(i=0;i<maxThreads;i++)
  {
    t.push_back(thread());
  }
  unsigned int numPerThread=slicesData.size()/maxThreads;
  unsigned int start;
  unsigned int end;
  for(i=0;i<maxThreads-1;i++)
  {
    start=(numPerThread*i);
    end=start+numPerThread;
    t[i]=thread(&Mesh::stabilityThread,this,start,end);
  }
  t[maxThreads-1]=thread(&Mesh::stabilityThread,this,end,slicesData.size());
  for(i=0;i<maxThreads;i++)
  {
    t[i].join();
  }
}

void Mesh::stabilityThread(unsigned int start,unsigned int end)
{
  //This method describes a thread that is called by computeStabilityModel(). It
  //is assigned a number of cross sections of the model and must compute the
  //stability of each point in the slice

  //First it is necessary to find the y value of the slices that is directly
  //below the current slice.

  //Then it is necessary to find all of the slices that match that y value
  //(there could be more than 1)

  //Finally, out of all of those slices, find which one is actually below the
  //current slice and use the stability calculated from it as the stability for
  //that point

  unsigned int i;
  for(i=start;i<end;i++)
  {
    double closestLowerY=findClosestLowerYValue(i);
    vector<pair<int,vector<VertexAttribs>>>lowerSlices;
    getLowerSlices(lowerSlices,closestLowerY);
    for(unsigned int j=0;j<slicesData[i].size();j++)
    {
      stabilityVector[i][j]=findBestStability(slicesData[i][j],lowerSlices);
    }
  }
}

double Mesh::findClosestLowerYValue(int i)
{
  //This method will find the y value of the slice directly below the slice
  //at index i

  double closestLowerY=slicesData[i][0].y;
  for(unsigned int j=0;j<slicesData.size();j++)
  {
    if(closestLowerY==slicesData[i][0].y)
    {
      if(slicesData[j][0].y<slicesData[i][0].y)
      {
        closestLowerY=slicesData[j][0].y;
      }
    }
    else
    {
      if(slicesData[i][0].y>slicesData[j][0].y)
      {
        double dif1=slicesData[i][0].y-slicesData[j][0].y;
        double dif2=slicesData[i][0].y-closestLowerY;
        if(dif1<dif2)
        {
          closestLowerY=slicesData[j][0].y;
        }
      }
    }
  }
  return closestLowerY;
}

void Mesh::getLowerSlices(vector<pair<int,vector<VertexAttribs>>>&lowerSlices,double lowY)
{
  //This method will find all of the slices that match the y value of the slice
  //directly below the current one
  for(unsigned int j=0;j<slicesData.size();j++)
  {
    if(slicesData[j][0].y==lowY)
    {
      lowerSlices.push_back(make_pair(j,slicesData[j]));
    }
  }
}

PointStability Mesh::findBestStability(VertexAttribs&v,SliceVec&lowerSlices)
{
  //This method takes all of the slices that could be below the current slice
  //and find the stability created by the slice that best supports the point
  //that is currently being tested
  PointStability bestStability;
  bool firstAttemptToFindBestStability=true;
  for(unsigned int i=0;i<lowerSlices.size();i++)
  {
    Perimeter slicePerimeter;
    fillSlicePerimeter(slicePerimeter,lowerSlices[i].second, lowerSlices[i].first);
    vector<double>clippingPoints;

    //determine if the point above is inside or outside the slice below. Do this
    //by drawing a line through this point along the x axis and finding how many
    //edges that the line clips that are to one side of the point. If the number
    //is odd, then the point is inside. Otherwise it is outside.
    getClipPoints(slicePerimeter,clippingPoints,v.z);
    int count=countNumToSide(clippingPoints,v.x);
    PointStability distance;
    if(count%2!=0)
    {

      //The point above is inside the slice below. Find how far inside it is
      distance=findDistance(v,slicePerimeter);
      distance.val*=-1;
    }
    else
    {
      //The point above is outside the slice below. Find how far outside it is
      distance=findDistance(v,slicePerimeter);
    }
    if(firstAttemptToFindBestStability)
    {
      bestStability=distance;
      firstAttemptToFindBestStability=false;
    }
    else
    {
      if(bestStability.val>distance.val)
      {
        bestStability=distance;
      }
    }
  }
  return bestStability;
}

void Mesh::fillSlicePerimeter(Perimeter&perim,vector<VertexAttribs>&lowerSlice,int sliceIndex)
{
  //This method links all of the vertices in a slice into edges

  for(unsigned int k=0;k<lowerSlice.size()-1;k++)
  {
    perim.second.push_back(make_pair(lowerSlice[k],lowerSlice[k+1]));
  }
  pair<VertexAttribs,VertexAttribs>finalEdge;
  finalEdge=make_pair(lowerSlice[lowerSlice.size()-1],lowerSlice[0]);
  perim.second.push_back(finalEdge);
  perim.first=sliceIndex;

}

void Mesh::getClipPoints(Perimeter&perim,vector<double>&clippingPoints,double z)
{
  //This method finds all of the x values of the clipping points on the line
  //that passes through the current vertex. A clipping point is a slice edge
  //crossed this line.

  for(unsigned int k=0;k<perim.second.size();k++)
  {
    double firstZ=perim.second[k].first.z;
    double secondZ=perim.second[k].second.z;
    if((firstZ>=z&&secondZ<z)||(firstZ<z&&secondZ>=z))
    {
      double xDif=perim.second[k].first.x-perim.second[k].second.x;
      double zDif=perim.second[k].first.z-perim.second[k].second.z;
      double zDif2=perim.second[k].first.z-z;
      double ratio=zDif2/zDif;
      clippingPoints.push_back(perim.second[k].first.x-(xDif*ratio));
    }
  }
  sort(clippingPoints.begin(),clippingPoints.end());
}

int Mesh::countNumToSide(vector<double>&clippingPoints,double x)
{
  //This method counts the number of clipping points that are to one side of the
  //current vertex

  int count=0;
  for(unsigned int k=0;k<clippingPoints.size();k++)
  {
    if(clippingPoints[k]<x)
    {
      count++;
    }
  }
  return count;
}

PointStability Mesh::findDistance(VertexAttribs&v,Perimeter&slicePerimeter)
{
  //This method finds the distance of a point in 2D space from a polygon which
  //describes the slice. Only the smallest distances is remembered

  double minEdgeDistance;
  double edgeDistance;
  unsigned int k;
  double xPt;
  double zPt;
  double xDif;
  double zDif;
  bool foundAnEdgeDistance=false;
  pair<int,pair<int,int>>lowerEdgeVerts=make_pair(-1,make_pair(-1,-1));
  for(k=0;k<slicePerimeter.second.size();k++)
  {
    VertexAttribs v1=slicePerimeter.second[k].first;
    VertexAttribs v2=slicePerimeter.second[k].second;
    double xDirEdge=v1.x-v2.x;
    double zDirEdge=v1.z-v2.z;
    double xDirPerp=-zDirEdge;
    double zDirPerp=xDirEdge;
    double edgeSlope=xDirEdge/zDirEdge;
    double slopeBetweenEdgeFirstAndPt=(v1.x-v.x)/(v1.z-v.z);
    if(slopeBetweenEdgeFirstAndPt==edgeSlope)
    {
      if((v1.x-v.x<=xDirEdge)&&(v1.z-v.z<=zDirEdge))
      {
        edgeDistance=0.0;
        foundAnEdgeDistance=true;
        if(k!=slicePerimeter.second.size()-1)
        {
          lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,k+1));
        }
        else
        {
          lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,0));
        }
        break;
      }
    }
    else
    {
      bool intersect1=false;
      bool intersect2=false;
      double magnitude=sqrt(((xDirEdge)*(xDirEdge))+(zDirEdge*zDirEdge));
      double newXEdge=xDirEdge/magnitude;
      double newZEdge=zDirEdge/magnitude;
      double newXPerp=xDirPerp/magnitude;
      double newZPerp=zDirPerp/magnitude;
      double denominator=((newXPerp*newXEdge)-(newZPerp*newZEdge));
      double a1=(newXEdge*(v1.z-v.z)+newZEdge*(v.x-v1.x))/denominator;
      double b1=((v1.x-v.x)+(newXPerp*a1))/newXEdge;
      double a2=(newXEdge*(v2.z-v.z)+newZEdge*(v.x-v2.x))/denominator;
      double b2=((v2.x-v.x)+(newXPerp*a2))/newXEdge;
      if(a1>=0&&b1>=0||a1<0&&b1<0)
      {
        intersect1=true;
      }
      if(a2>=0&&b2>=0||a2<0&&b2<0)
      {
        intersect2=true;
      }
      if((intersect1&&intersect2)||(!intersect1&&!intersect2))
      {
        continue;
      }
      else
      {
        double num;
        double denominator;
        if(intersect1)
        {
          if(a1>=0)
          {
            num=(v2.z*-newXPerp-newZPerp*v.x-v.z*-newXPerp+newZPerp*v2.x);
            denominator=((-newXEdge*-newZPerp)+newZEdge*-newXPerp);
            double c=num/denominator;
            xPt=v2.x-newXEdge*c;
            zPt=v2.z-newZEdge*c;
            xDif=v.x-xPt;
            zDif=v.z-zPt;
            edgeDistance = sqrt(xDif*xDif+zDif*zDif);
            if(k!=slicePerimeter.second.size()-1)
            {
              lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,k+1));
            }
            else
            {
              lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,0));
            }
            foundAnEdgeDistance=true;
          }
          else
          {
            num=(v2.z*-newXPerp+newZPerp*v.x-v.z*newXPerp-newZPerp*v2.x);
            denominator=((-newXEdge*newZPerp)+newZEdge*newXPerp);
            double c=num/denominator;
            xPt=v2.x-newXEdge*c;
            zPt=v2.z-newZEdge*c;
            xDif=v.x-xPt;
            zDif=v.z-zPt;
            edgeDistance = sqrt(xDif*xDif+zDif*zDif);
            if(k!=slicePerimeter.second.size()-1)
            {
              lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,k+1));
            }
            else
            {
              lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,0));
            }
            foundAnEdgeDistance=true;
          }
        }
        else
        {
          if(a2>=0)
          {
            num=(v1.z*-newXPerp-newZPerp*v.x-v.z*-newXPerp+newZPerp*v1.x);
            denominator=((newXEdge*-newZPerp)-newZEdge*-newXPerp);
            double c=num/denominator;
            xPt=v1.x+newXEdge*c;
            zPt=v1.z+newZEdge*c;
            xDif=v.x-xPt;
            zDif=v.z-zPt;
            edgeDistance = sqrt(xDif*xDif+zDif*zDif);
            if(k!=slicePerimeter.second.size()-1)
            {
              lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,k+1));
            }
            else
            {
              lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,0));
            }
            foundAnEdgeDistance=true;
          }
          else
          {
            num=(v1.z*-newXPerp+newZPerp*v.x-v.z*newXPerp-newZPerp*v1.x);
            denominator=((newXEdge*newZPerp)-newZEdge*newXPerp);
            double c=num/denominator;
            xPt=v1.x+newXEdge*c;
            zPt=v1.z+newZEdge*c;
            xDif=v.x-xPt;
            zDif=v.z-zPt;
            edgeDistance = sqrt(xDif*xDif+zDif*zDif);
            if(k!=slicePerimeter.second.size()-1)
            {
              lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,k+1));
            }
            else
            {
              lowerEdgeVerts=make_pair(slicePerimeter.first, make_pair(k,0));
            }
            foundAnEdgeDistance=true;
          }
        }
      }
    }
    if(!foundAnEdgeDistance)
    {
      minEdgeDistance=edgeDistance;
    }
    else
    {
      if(minEdgeDistance>edgeDistance)
      {
        minEdgeDistance=edgeDistance;
      }
    }
  }
  xDif=slicePerimeter.second[0].first.x-v.x;
  zDif=slicePerimeter.second[0].first.z-v.z;
  double pointDistance=sqrt(xDif*xDif+zDif*zDif);
  double dif;
  pair<int,pair<int,int>>lowerPointVerts=make_pair(slicePerimeter.first,make_pair(0, 0));
  for(k=0;k<slicePerimeter.second.size();k++)
  {
    xDif=slicePerimeter.second[k].first.x-v.x;
    zDif=slicePerimeter.second[k].first.z-v.z;
    dif=sqrt(xDif*xDif+zDif*zDif);
    if(dif<pointDistance)
    {
      pointDistance=dif;
      lowerPointVerts=make_pair(slicePerimeter.first,make_pair(k,k));
    }
  }
  PointStability p;
  if(!foundAnEdgeDistance)
  {
    p.val=pointDistance;
    p.sliceIndex=lowerPointVerts.first;
    p.supportIndex1=lowerPointVerts.second.first;
    p.supportIndex2=lowerPointVerts.second.second;
    //if(p.sliceIndex==-1)
    //{
    //  cout<<"here"<<endl;
    //}
    return p;
  }
  else
  {
    if(edgeDistance<pointDistance)
    {
      p.val=edgeDistance;
      p.sliceIndex=lowerEdgeVerts.first;
      p.supportIndex1=lowerEdgeVerts.second.first;
      p.supportIndex2=lowerEdgeVerts.second.second;
    }
    else
    {
      p.val=pointDistance;
      p.sliceIndex=lowerPointVerts.first;
      p.supportIndex1=lowerPointVerts.second.first;
      p.supportIndex2=lowerPointVerts.second.second;
    }
    //if(p.sliceIndex==-1)
    //{
    //  cout<<"here"<<endl;
    //}
    return p;
  }
}

void Mesh::adjustStability()
{
  for(unsigned int i=1;i<slicesData.size();i++)
  {
    //cout<<"i="<<i<<endl;
    //if(i==23)
    //{
    //  cout<<i<<endl;
    //}
    for(unsigned int j=0;j<slicesData[i].size();j++)
    {
      //cout<<"j="<<j<<endl;
      PointStability pointStability = stabilityVector[i][j];
      //cout<<"pointStability"<<endl;
      //cout<<"pointStability slice = "<<pointStability.sliceIndex<<endl;
      //cout<<"pointStability support 1 = "<<pointStability.supportIndex1<<endl;
      PointStability lowerStability1=stabilityVector[pointStability.sliceIndex][pointStability.supportIndex1];
      //cout<<"support 1"<<endl;
      PointStability lowerStability2=stabilityVector[pointStability.sliceIndex][pointStability.supportIndex2];
      //cout<<"support 2"<<endl;
      if(lowerStability1.val>=lowerStability2.val)
      {
        if(lowerStability1.val>=pointStability.val)
        {
          pointStability.val=lowerStability1.val;
          stabilityVector[i][j]=pointStability;
        }
        else
        {
          stabilityVector[i][j]=pointStability;
        }
      }
      else if(lowerStability2.val>=lowerStability1.val)
      {
        if(lowerStability2.val>=pointStability.val)
        {
          pointStability.val=lowerStability2.val;
          stabilityVector[i][j]=lowerStability2;
        }
        else
        {
          stabilityVector[i][j]=pointStability;
        }
      }
    }
  }
}

void Mesh::printSlices()
{
  //This method prints slice data for debugging purposes

  ofstream outFile("slices.txt");
  if(outFile.is_open())
  {
    unsigned int i;
    for(i=0;i<sliceVertexVec.size();i++)
    {
      outFile<<"slice "<<i<<" y="<<slicesData[i][0].y<<endl;
      for(unsigned int j=0;j<sliceVertexVec[i].size();j++)
      {
        outFile<<"vertex1"<<sliceVertexVec[i][j].first;
        outFile<<" vertex2"<<sliceVertexVec[i][j].second;
        outFile<<" x="<<slicesData[i][j].x;
        outFile<<" z="<<slicesData[i][j].z;
        outFile<<" stability="<<stabilityVector[i][j].val;
        outFile<<" supporting slice="<<stabilityVector[i][j].sliceIndex;
        outFile<<" supporting vertex1="<<stabilityVector[i][j].supportIndex1;
        outFile<<" supporting vertex2="<<stabilityVector[i][j].supportIndex2;
        outFile<<endl;
      }
    }
    outFile<<endl;
    outFile.close();
  }
  else
  {
    cout<<"Failed to open stability file for writing"<<endl;
  }
}

Mesh::~Mesh(void)
{
  //Nothing to do
}

void Mesh::draw(GLint objColLoc, double tolerance)
{
  //total=0;
  //Display the model on the screen
  for(unsigned int i=0;i<slicesData.size();i++)
  {
    drawSlice(i,objColLoc, tolerance);
  }
  //cout<<total<<endl;
}

void Mesh::drawSlice(unsigned int i,GLint objColLoc, double tolerance)
{
  //Draw line loops (or points depending on the commenting) representing each
  //slice. Unstable points will be colored red. Stable points will be colored
  //green
  //glBegin(GL_LINE_LOOP);
  for(unsigned j=0;j<slicesData[i].size();j++)
  {
    glm::vec3 color;
    if(stabilityVector[i][j].val>tolerance)
    {
      //cout<<i<<" "<<j<<endl;
      color=glm::vec3(1,0,0);
    }
    else
    {
      color=glm::vec3(0,1,0);
    }
    glVertexAttrib3fv(objColLoc,glm::value_ptr(color));
    glBegin(GL_POINTS);
    VertexAttribs v=slicesData[i][j];
    glVertex3d(v.x,v.y,v.z);
    glEnd();
    //total++;
  }
  //glEnd();
}



