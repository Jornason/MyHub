#ifndef OBJECT_H_
#define OBJECT_H_
#include<GL/glew.h>
#include<GL/gl.h>
#include<vector>
#include<string>
#include<map>
#include<set>
#include<glm/glm.hpp>
#include<glm/gtc/type_ptr.hpp>
#include<stack>
using namespace std;

/* Define a buffer offset to be a void pointer */
#define BUFFER_OFFSET(offset)((void*)(offset))

/* The vertex attribute struct */
struct VertexAttribs
{
    double x;
    double y;
    double z;
    double w;
};


/* Object class
 * This class represents anything that can be rendered on the screen. It serves as a base
 * for other drawable classes */
class Object
{
  protected:

    /* Identify the buffers that will be used to hold object information so the GPU can
     * find them */
    enum Buffer_IDs
    {
      VertexBuffer,IndexBuffer,NumBuffers
    };

    /* Identify vertex attribute information */
    enum Attrib_IDs
    {
      vPosition=0
    };

  protected:

    /* The vertex array object (the thing that identifies this object to the GPU */
    GLuint VAO;

    /* The buffers to hold all of the information */
    GLuint buffers[NumBuffers];

    /* This holds all of the position data about each vertex */
    vector<VertexAttribs>vertexData;

    /* This holds all of triangle face information (which vertices correspond to a
     * triangle) */
    vector<GLuint>triangleIndices;

    /* The color of this object */
    glm::vec3 color;

    /* This describes how this object has been transformed */
    stack<glm::mat4>transform;

    /* The name of the object */
    string name;

  public:

    /* Constructor */
    Object(string name="")
    {
      /* Reserve an identifer for this object and bind it to the object so that subsquent
       * commands apply to it */
      glGenVertexArrays(1,&VAO);
      glBindVertexArray(VAO);
      /* Generate buffers for this object */
      glGenBuffers(NumBuffers,buffers);
      /* Set the object's name */
      setName(name);
    }

    /* Destructor */
    virtual~Object(void)
    {
      /* If the object is recognized by the GPU, remove it from the GPU's scope */
      if(VAO!=0)
      {
        glDeleteBuffers(NumBuffers,buffers);
        glDeleteVertexArrays(1,&VAO);
      }
    }

    /* Draw the object */
    virtual void draw(GLint objColLoc, double tolerance)
    {
      /* All subsequent commands will only apply to this object */
      glBindVertexArray(VAO);
      /* Draw the elements of this object as triangles */
      unsigned int tSize=triangleIndices.size();
      glDrawElements(GL_TRIANGLES,tSize,GL_UNSIGNED_INT,BUFFER_OFFSET(0));
    }

    /* Setter and getter fror the transformation matrix */
    void setTransform(glm::mat4&obj)
    {
      transform.push(obj);
    }
    glm::mat4 getTransform()
    {
      return transform.top();
    }

    /* Remove something from the transformation stack */
    void clearTransform()
    {
      transform.pop();
    }

    /* Set the object's name */
    void setName(const string&name)
    {
      this->name=name;
    }

    /* Setter and getter for the object's color */
    virtual void setColor(float r,float g,float b)
    {
      color=glm::vec3(r,g,b);
    }
    glm::vec3 getColor(){
      return color;
    }

    /* Pass the object to the GPU */
    void passToGPU()
    {
      /* All subsequent commands apply to this object */
      glBindVertexArray(VAO);
      /* Bind the Vertex Buffer to this object */
      glBindBuffer(GL_ARRAY_BUFFER,buffers[VertexBuffer]);
      /* Fill the Vertex Buffer for this object */
      size_t sizeOfVBuffer=sizeof(VertexAttribs)*vertexData.size();
      glBufferData(GL_ARRAY_BUFFER,sizeOfVBuffer,&vertexData[0],GL_STATIC_DRAW);
      /* Bind the triangle Index buffer for this object */
      glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,buffers[IndexBuffer]);
      /* Fill the triangle index buffer for this object */
      size_t sizeOfTBuffer=sizeof(GLuint)*triangleIndices.size();
      const GLvoid*data=&triangleIndices[0];
      glBufferData(GL_ELEMENT_ARRAY_BUFFER,sizeOfTBuffer,data,GL_STATIC_DRAW);
      /* Again, bind the vertex Buffer */
      glBindBuffer(GL_ARRAY_BUFFER,buffers[VertexBuffer]);
      /* Tell the GPU where to find each vertex */
      glVertexAttribPointer(vPosition,4,GL_FLOAT,0,sizeof(VertexAttribs),BUFFER_OFFSET(0));
      /* Enable to position attribute for each vertex */
      glEnableVertexAttribArray(vPosition);
      /* Unbind the VAO for this object */
      glBindVertexArray(0);
    }
};
#endif
