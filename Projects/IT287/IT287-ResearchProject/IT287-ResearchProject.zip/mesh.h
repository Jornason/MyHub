#ifndef MESH_H_
#define MESH_H_
#include"Object.h"
#include<list>
using namespace std;

struct PointStability
{
    double val;
    int sliceIndex;
    int supportIndex1;
    int supportIndex2;
};

class Mesh:public Object
{
    typedef set<int>TriSet;
    typedef TriSet::iterator TriIter;
    typedef map<int,TriSet>InnerMap;
    typedef InnerMap::iterator IMIter;
    typedef std::map<int,InnerMap>Graph;
    typedef Graph::iterator GIter;
    typedef vector<std::pair<int,int>>EList;
    typedef EList::iterator EIter;
    typedef pair<int,vector<pair<VertexAttribs,VertexAttribs>>> Perimeter;
    typedef vector<pair<int,vector<VertexAttribs>>> SliceVec;
    typedef vector<VertexAttribs> VData;
  private:
    Graph graph;
    vector<vector<VertexAttribs>>slicesData;
    vector<vector<PointStability>>stabilityVector;
    double maximumThicknessOfSlice;
    VData sortedVertexData;
    double y;
    vector<EList>sliceVertexVec;
    long total;
  private:
    void drawSlice(unsigned int i,GLint objColorLoc, double tolerance);
    bool readInputMesh(string&filenm, int orientation);
    void createGraph();
    void cutTheModelIntoSlices();
    void createIndividualSlice();
    void findStraddlingVertex(GIter&mainGraphIter);
    void cleanGraph(Graph&savedGraph);
    void clipAlongYPlane(EList&slice,int edgeVertex1,int edgeVertex2);
    void getNextSliceEdge(int eV1,int eV2,int&nxtEV1,int&nxtEV2,int t);
    vector<VertexAttribs> getSliceVertices(EList&slice);
    void computeStabilityModel();
    void stabilityThread(unsigned int start,unsigned int end);
    double findClosestLowerYValue(int i);
    void getLowerSlices(SliceVec&lowerSlices,double lowY);
    PointStability findBestStability(VertexAttribs&v,SliceVec&lowerSlices);
    void getBestSlice(SliceVec&lowSlices,vector<double>&result,unsigned int i);
    double testSlice(VData&lowerSlice,vector<double>&stability,unsigned int i);
    void fillSlicePerimeter(Perimeter&perim,VData&lowerSlice, int sliceIndex);
    void getClipPoints(Perimeter&perim,vector<double>&clippingPoints,double z);
    int countNumToSide(vector<double>&clippingPoints,double x);
    PointStability findDistance(VertexAttribs&v,Perimeter&slicePerimeter);
    void adjustStability();
    void printSlices();
  public:
    Mesh(string name,string filename,int orientation);
    ~Mesh(void);
    void draw(GLint objColLoc, double tolerance);

};
#endif
