#ifndef VIEW_H
#define VIEW_H
#include<GL/glew.h>
#include<GL/gl.h>
#include<string>
#include<stack>
#include<glm/glm.hpp>
#include"Object.h"
using namespace std;

/* The View class holds everything involves with rendering the scene */
class View{

    /* Define a buffer offset to be a void pointer */
    #define BUFFER_OFFSET(offset)((void*)(offset))

    /* The information passed to create the shader */
    typedef struct{
        GLenum type;
        string filename;
        GLuint shader;}
    ShaderInfo;

  public:

    /* Constructor */
    View();

    /* Destructor */
    ~View();

    /* Resize the window */
    void resize(int w,int h);

    /* Initialize everything */
    void initialize(int orientation);

    /* Draw the scene */
    void draw(float deltaXAngle,float deltaYAngle,double tolerance,double scale);

    /* Useful information about OpenGL */
    void getOpenGLVersion(int*major,int*minor);
    void getGLSLVersion(int*major,int*minor);

  public:

    /* The list of objects in the scene */
    vector<Object*>objectsList;
    string filename;
    string name;

  protected:

    /* Compile and link the shaders */
    GLuint createShaders(ShaderInfo*shaders);

    /* Print shader compilation error info */
    void printShaderInfoLog(GLuint shader);

  private:

    /* Window dimensions */
    int WINDOW_WIDTH,WINDOW_HEIGHT;

    /* Identifiers for the GPU to find important information */
    GLint projLoc,mvLoc,objColLoc;

    /* Matrices to hold projection and transformation information */
    glm::mat4 proj,modelview;
};
#endif
