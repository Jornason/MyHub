Compile with javac *.java

Run with java -cp . -Xmx256m -Xss256m DepthFirstTwentyFortyEight debug

OR

java -cp . [INSERT MEMORY ALLOTMENT HERE] BreadthFirstTwentyFortyEight debug


Breadth first WILL fail for 2048 unless you have more memory than exists in the universe
(probably).